# ZControl 播放器重构说明：自研播放器 → ArtPlayer 统一替换

> 文档版本：2026-07-26
> 范围：将项目内全部视频播放场景（哔哩哔哩、点播、直播、WebRTC 直连、"一起看"同步、弹幕）统一迁移到开源播放器 **ArtPlayer**（v5.4.0），并保留/魔改关键业务功能。

---

## 1. 背景与目标

原项目使用自研视频播放器，包含 MSE / HLS / FLV / Direct 四层引擎与一整套自写 UI（进度条、控制栏、快捷键、自动隐藏、音量/倍速面板等）。随着功能增长，自研 UI 维护成本高、与"一起看"同步、弹幕、字幕等模块耦合严重。

**目标**
1. 统一替换：移除自研播放器 UI，集成 ArtPlayer 作为所有视频场景的统一播放器（含哔哩哔哩与其他视频源）。
2. 哔哩哔哩适配：B 站解析与加载在 ArtPlayer 下正常运行。
3. 功能魔改：
   - "一起看"同步播放（进度同步、播放状态同步）
   - 自定义挂载弹幕（发送与显示）
   - 弹幕显示列表（查看/管理弹幕记录）——新增功能
4. 功能完整性：原有功能不遗漏、不降级，适配度尽量高。

---

## 2. 核心架构决策

**引擎层保留，UI 层替换。** 现有代码分两层：

| 层 | 内容 | 处理方式 |
|---|---|---|
| 流媒体引擎层 | MSE DASH 双轨合并 / HLS / FLV / Direct + `usePlayerSource` 串行队列 + 哔哩哔哩解析（前后端） | **完整保留**。B 站音视频分离 DASH 必须靠它，ArtPlayer 不具备此能力 |
| 播放器 UI 层 | `<video>` JSX + VideoControls + ProgressTrack + 自写快捷键/自动隐藏 | **全部移除**，由 ArtPlayer 接管（进度条/播放暂停/音量/倍速/全屏/大按钮/加载动画/快捷键/迷你进度条） |

**关键事实**：ArtPlayer 的 `art.video` 就是原生 `<video>` 元素。同步层（`useWatchTogether → useVideoSource → usePlayerSource → 引擎`）与弹幕引擎、字幕 hook 全部围绕原生 video 元素工作，因此**零改动**复用。

---

## 3. 模块拆分

| 模块 | 变更 |
|---|---|
| `src/modules/art-player/` （新增） | ArtPlayer 封装核心：`art-shared.ts`（守卫/CONTEXTMENU/插槽）、`useArtPlayer.ts`（生命周期）、`art-overrides.css`、`LiveArtPlayer.tsx`（直播包装）、`controls/ArtControlButton.tsx`、`useVideoPlayingState.ts`、`index.ts` |
| `watch-together/WatchTogetherPanel.tsx` | 重写为 Shell：创建 ArtPlayer + 接守卫 + 挂载弹幕层，业务委托给 Core |
| `watch-together/WatchTogetherCore.tsx` | 业务核心：平移全部"一起看"逻辑（同步/审批/弹幕/字幕/清晰度/快捷键），Portal UI |
| `watch-together/DanmakuListPanel.tsx` | **新增**：弹幕列表面板（时间轴+实时双 Tab、搜索、点击跳转、房主屏蔽/删除） |
| `store/danmakuStore.ts` | 扩展：新增 `realtimeLog`（实时弹幕记录，上限 500 条）与屏蔽关键词 |
| `screen-sharing/FlvPlayer.tsx` | 重写为 ArtPlayer `isLive` + flv.js customType，保留重试/卡顿恢复/统计上报，props 契约不变 |
| `screen-sharing/RemoteVideoPlayer.tsx` | 统一 `LiveArtPlayer` 包装（WebRTC `srcObject` 直接绑定 `art.video`） |
| `pages/DirectWatchPage.tsx`、`pages/DirectSharePage.tsx`、`screen-sharing/SharePage.tsx` | 迁移为 `LiveArtPlayer`（WebRTC 流） |
| **删除** | `VideoPlayer/VideoControls.tsx`、`VideoPlayer/ProgressTrack.tsx`、`VideoPlayer/useVideoControls.ts`、`VideoPlayer/format.ts`、`VideoPlayer/hooks/*`（useControlsVisibility/usePanelDismiss/usePlayerShortcuts）、`VideoPlayer/parts/VolumeControl.tsx`、`parts/RateControl.tsx`、死代码 `player/hooks/*`（usePlayer/usePlayerControls/usePlayerEvents） |
| **不动** | `sync-playback` 全部 hooks、引擎层、哔哩哔哩解析前后端、`useSubtitles`、弹幕 providers、**后端零改动** |

---

## 4. 关键兼容性处理（已验证方案）

1. **观众只读**：移除 `playAndPause` 控件；在祖先容器 `$player` 的 capture 阶段 `stopPropagation` 拦截
   - 视频点击（`$video` click → `art.toggle()`）
   - 大播放按钮（`$state` click → `art.play()`）—— 不拦截会让观众本地播放导致脱同步
   - 进度条 `pointerdown`/`mousedown`/`touchstart`/`click`（转为"申请跳转"）
   - `hotkey: false`（观众端）；`hotkey: true`（房主端）
2. **ArtPlayer 错误重连冲突**：始终保持 `option.url` 为空（源由引擎层以 MSE blob 驱动），使 ArtPlayer 内置 reconnect 退化为无害 loading，不会用裸 URL 覆盖引擎管理的 `src`；capture 阶段额外拦截 `error` 事件防穿透。
3. **字幕**：`<track>` 元素以 `data-zc` 标记命令式追加到 `art.video`，按元素序映射 `textTracks` 设置 `mode`，避开 ArtPlayer 自带 `$track`；`loadstart` 时重应用（顺带修复旧版 reload 后字幕丢失隐患）。
4. **弹幕层**：作为 ArtPlayer `layers` 挂载（`art.layers.show = true`），z-index 40 在控制栏（60）之下，**原生全屏时弹幕可见**（layer 在 player 根内）。
5. **B 站权威 duration**：引擎已设置 `MediaSource.duration`，ArtPlayer 进度条直接读 `video.duration` 即正确。
6. **网页全屏**：保留受控 portal 方案（RoomLayout 契约不变）；ArtPlayer 内置 `fullscreen`（原生全屏）启用。
7. **清晰度切换**：复用 `applyQualityChange`（重解析+广播），UI 换为 ArtPlayer 原生 selector 控件（房主端）。
8. **右键统计菜单**：`Artplayer.CONTEXTMENU = false` 禁用内置右键，继续绑定 `art.video` 的 `contextmenu` 到自有 `VideoStatsMenu`。

---

## 5. 各场景适配要点

### 5.1 哔哩哔哩
- 解析全链路（前端请求 → 后端代理 CDN → 返回 DASH）不动。
- 引擎层将 DASH 双轨（音/视频）合并为单个 MSE 源驱动 `art.video`，清晰度切换、官方弹幕加载照旧工作。
- MP4 降级路径保留。

### 5.2 "一起看"同步
- **房主**：`useHostBroadcast` 周期广播 `currentTime`/`paused`，初始状态恢复、房主心跳不变。
- **观众**：`useViewerStateSync` 跟随房主；进度条交互经守卫拦截后转为"申请跳转"，房主端 `autoApprove` 或手动审批。
- 同步层依赖 `video` 元素，因 `art.video` 即原生 video，逻辑零改动。

### 5.3 弹幕
- `danmakuEngine.ts` 弹幕引擎原样保留（多轨道/过滤/样式/屏蔽词），挂载为 ArtPlayer `layers`。
- 实时弹幕发送走既有 socket 通道；新增 `realtimeLog` 记录实时弹幕。
- **新增弹幕列表面板**：时间轴弹幕 + 实时弹幕双 Tab，支持搜索、点击跳转播放点、房主屏蔽/删除。

### 5.4 直播 / WebRTC
- HTTP-FLV 直播：`LiveArtPlayer`（`isLive` + flv.js customType），保留重试/卡顿恢复/统计上报。
- WebRTC 直连流：`art.video.srcObject = stream` 直接绑定，`isLive` 隐藏进度条。

---

## 6. 迁移步骤（执行顺序）

1. `art-player` 核心封装（`art-shared` / `useArtPlayer` / css / 直播包装 / 控件按钮 / 状态 hook / 导出）
2. `WatchTogetherPanel` 重写（同步 / 审批 / 弹幕 / 字幕平移）
3. 自定义控制栏 + 设置面板适配
4. 弹幕层挂载到 ArtPlayer
5. 弹幕列表面板（新功能）
6. 哔哩哔哩链路验证
7. 直播 / WebRTC 迁移
8. 删除旧播放器代码 + 构建验证

---

## 7. 验证结果

| 项目 | 结果 |
|---|---|
| `npx tsc --noEmit` | ✅ 通过（exit 0） |
| `npm run build`（vite 生产构建） | ✅ 成功，产物 `dist/assets/index-*.js` |
| 产物集成标记 | ✅ 含 `artplayer`、`art-layer`(13处)、`isLive`(9处)、`申请跳转`、`弹幕列表`、`一起看` |
| 后端服务（:3333） | ✅ 存活，`POST /api/auth/login` → 200 |
| 前端 preview（:4173） | ✅ 返回 200，HTML 正确引用构建产物 |
| 悬挂引用检查 | ✅ 无残留对旧 `VideoControls`/`VolumeControl`/`RateControl`/`usePlayer*` 的引用 |
| 守卫/弹幕图层接线 | ✅ `installViewerGuards`、`hotkey:isHost`、`layers:[...]`、`art.layers.show=true` 复核无误 |

**说明**：`npm run build` 前需先 `rm -rf dist`——`dist` 中含中文命名光标资源目录（如 `Black_10`）会导致沙箱清理失败。

---

## 8. 待办与风险

- ⚠️ **交互式浏览器渲染冒烟测试未完成**：创建房间 → ArtPlayer 渲染 → 同步/弹幕/清晰度切换的肉眼验证，因浏览器自动化（agent-browser）配额耗尽（429 硬限额）在本轮未执行。建议浏览器配额恢复后补测。
  - 测试账号：`arttest / ArtTest123456`（dev.sqlite，role=root，status=active）
- 运行期兼容性（观众守卫拦截、原生全屏弹幕可见性、错误重连规避）已通过源码静态复核与产物验证，但仍建议人工回归确认体验。
- 后端零改动，前端数据契约（socket 事件、哔哩哔哩 API、弹幕协议）保持兼容。

---

## 9. 知识沉淀

本次踩坑的 ArtPlayer 集成要点（click-toggle 绑定在 `$video`、`$state` 大按钮、进度条 capture 拦截、原生全屏弹幕 `layers` 挂载、错误重连规避、字幕 `data-zc` 标记）已固化为用户级技能 `artplayer-react-integration`，供后续同类任务复用。
