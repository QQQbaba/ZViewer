import {
  type ReactNode,
  Children,
  Fragment,
  isValidElement,
  useEffect,
  useRef,
  useState,
} from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, PanelRight, PanelRightClose } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Title } from '@/components/ui/Typography'
import { Spinner } from '@/components/ui/Spinner'
import { message } from '@/components/ui/message'
import { SegmentedToggle } from '@/components/ui/SegmentedToggle'
import { useRoomStore, type RoomMode } from '@/store/roomStore'
import { useSocket } from '@/hooks/useSocket'
import { SharingStatusPanel } from '@/modules/room/components/SharingStatusPanel'
import type { SharingMode } from '@/modules/screen-sharing/hooks/useConnectionStats'

interface RoomLayoutProps {
  /** 房间 ID，用于模式切换 socket 事件 */
  roomId: string
  /** 是否房主：房主可切换模式，观众只显示当前模式标签 */
  isHost: boolean
  title?: string
  onBack?: () => void
  headerActions?: ReactNode
  /** 当前模式对应的主区域内容（watch-together / screen-share） */
  mainContent: ReactNode
  controls?: ReactNode
  /** 非共享状态下右侧面板内容（影片列表、观看影片控件等） */
  rightPanel: ReactNode
  /**
   * 共享状态下的 RTCPeerConnection 实例。
   * 当前由调用方按需传入（未来通过 ref/context 从 SharePage/WatchPage 提升后接入）。
   */
  peerConnection?: RTCPeerConnection | null
  /** 共享角色：发送端 / 接收端 */
  sharingRole?: 'sender' | 'receiver'
  /** 共享模式标签，默认服务器中转 */
  sharingMode?: SharingMode
  /** P2P 直连开关当前状态（Task 6.3 接入） */
  p2pEnabled?: boolean
  /** P2P 直连开关回调（Task 6.3 接入） */
  onToggleP2P?: (enabled: boolean) => void
  /**
   * 显式覆盖共享状态判断。
   * 未提供时，自动判断为 `mode === 'screen-share' && store.isSharing`。
   */
  sharingActive?: boolean
  /**
   * CSS 模拟的网页全屏状态（由播放器组件如 WatchTogetherPanel 提升）。
   * 用于在网页全屏时隐藏底部卡片等页面元素。
   */
  webFullscreen?: boolean
}

const MODE_LABELS: Record<RoomMode, string> = {
  'watch-together': '一起看',
  'screen-share': '投屏',
}

const MODE_ORDER: RoomMode[] = ['watch-together', 'screen-share']

export function RoomLayout({
  roomId,
  isHost,
  title,
  onBack,
  headerActions,
  mainContent,
  controls,
  rightPanel,
  peerConnection = null,
  sharingRole = 'sender',
  sharingMode = 'server-relay',
  p2pEnabled,
  onToggleP2P,
  sharingActive,
  webFullscreen = false,
}: RoomLayoutProps) {
  const navigate = useNavigate()
  const { socket } = useSocket()
  const exitRoom = useRoomStore((state) => state.exitRoom)
  const defaultBack = () => {
    // 房主返回主页时关闭旧房间，避免 socket 仍 joined 到旧 room、
    // 旧 sharer session 残留，导致下次创建新房间时收到旧房间事件。
    if (socket && isHost) {
      socket.emit('close-room', () => {
        /* ack，无需提示 */
      })
    }
    // 明确退出房间：清除 activeRoomId + 重置房间状态
    exitRoom()
    navigate('/')
  }
  const handleBack = onBack ?? defaultBack
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true)
  const toggleRightPanel = () => setIsRightPanelOpen((open) => !open)

  // 检测浏览器原生全屏状态：原生全屏时右侧面板采用悬浮覆盖，非全屏时为固定侧边栏
  const [isNativeFullscreen, setIsNativeFullscreen] = useState(false)
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsNativeFullscreen(!!document.fullscreenElement)
    }
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    handleFullscreenChange()
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
    }
  }, [])

  const roomMode = useRoomStore((state) => state.mode)
  const setMode = useRoomStore((state) => state.setMode)
  const storeIsSharing = useRoomStore((state) => state.isSharing)

  // 模式切换加载占位：房主点击切换后等待后端确认期间显示 Spinner
  const [isModeSwitching, setIsModeSwitching] = useState(false)

  // 用于保护模式切换过程中的竞态：记录当前请求的 id 与超时定时器
  const switchingRef = useRef<{
    id: number
    timer: ReturnType<typeof setTimeout> | null
  } | null>(null)

  const isSharing =
    sharingActive ?? (roomMode === 'screen-share' && storeIsSharing)

  // 播放器容器使用固定高度（calc(100vh - 220px)），不使用 aspect-video，
  // 避免右侧面板内容撑开导致播放器高度变化。

  // 监听 room-mode-changed：观众端跟随房主切换无需刷新；
  // 同时清除本地加载占位（房主切换完成后）。
  useEffect(() => {
    if (!socket) return

    const handleRoomModeChanged = (data: { mode: RoomMode }) => {
      setMode(data.mode)
      setIsModeSwitching(false)
    }

    const handleDisconnect = () => {
      if (switchingRef.current) {
        if (switchingRef.current.timer) {
          clearTimeout(switchingRef.current.timer)
        }
        switchingRef.current = null
        setIsModeSwitching(false)
        message.error('连接已断开，请刷新页面后重试')
      }
    }

    socket.on('room-mode-changed', handleRoomModeChanged)
    socket.on('disconnect', handleDisconnect)

    return () => {
      if (switchingRef.current?.timer) {
        clearTimeout(switchingRef.current.timer)
      }
      switchingRef.current = null
      setIsModeSwitching(false)
      socket.off('room-mode-changed', handleRoomModeChanged)
      socket.off('disconnect', handleDisconnect)
    }
  }, [socket, setMode])

  const handleSwitchMode = (targetMode: RoomMode) => {
    if (!socket || !isHost || targetMode === roomMode || isModeSwitching) {
      return
    }

    const nextId = (switchingRef.current?.id ?? 0) + 1
    if (switchingRef.current?.timer) {
      clearTimeout(switchingRef.current.timer)
    }
    switchingRef.current = { id: nextId, timer: null }
    setIsModeSwitching(true)

    const timer = setTimeout(() => {
      if (switchingRef.current?.id === nextId) {
        switchingRef.current = null
        setIsModeSwitching(false)
        message.error('切换超时，请重试')
      }
    }, 5000)

    switchingRef.current.timer = timer

    socket.emit(
      'update-room-mode',
      { roomId, mode: targetMode },
      (response: {
        success: boolean
        message?: string
        data?: { mode?: RoomMode }
      }) => {
        if (switchingRef.current?.id !== nextId) {
          return
        }
        if (switchingRef.current.timer) {
          clearTimeout(switchingRef.current.timer)
        }
        switchingRef.current = null

        // 后端 AckResponse 标准格式：mode 在 data 字段内
        const mode = response.data?.mode
        if (response.success && mode) {
          setMode(mode)
        } else {
          message.error(response.message ?? '切换模式失败')
        }
        setIsModeSwitching(false)
      }
    )
  }

  // 共享状态下：侧栏显示「共享情况」面板，评论区（rightPanel）移动到下方 controls 区域
  const effectiveRightPanel = isSharing ? (
    <SharingStatusPanel
      pc={peerConnection}
      mode={sharingRole}
      sharingMode={sharingMode}
      p2pEnabled={p2pEnabled}
      onToggleP2P={onToggleP2P}
    />
  ) : (
    rightPanel
  )

  // 共享状态下：将评论区（rightPanel）追加到下方 controls 区域与原 controls 合并渲染
  const effectiveControls = isSharing ? (
    controls ? (
      <>
        {controls}
        {rightPanel}
      </>
    ) : (
      rightPanel
    )
  ) : (
    controls
  )

  // 根据当前模式渲染主区域：切换中显示加载占位，否则渲染调用方传入的 mainContent
  const renderMainContent = () => {
    if (isModeSwitching) {
      return (
        <div className="flex h-full w-full items-center justify-center">
          <Spinner tip="正在切换模式..." size={32} />
        </div>
      )
    }

    return mainContent
  }

  // 顶部模式切换栏：房主显示两个按钮（当前模式高亮），观众只显示当前模式标签
  // 使用 Google Monet 主题变量 + 玻璃拟态效果 + 增强边框
  const modeSwitchBar = isHost ? (
    <SegmentedToggle
      options={MODE_ORDER.map((m) => ({ value: m, label: MODE_LABELS[m] }))}
      value={roomMode}
      onChange={(value) => handleSwitchMode(value as RoomMode)}
      disabled={isModeSwitching}
    />
  ) : (
    <div
      className="glass-strong rounded-full border border-[var(--md-sys-color-outline)] px-4 py-1.5 text-xs font-medium shadow-lg ring-1 ring-[var(--md-sys-color-outline-variant)]/40"
      style={{
        backgroundColor: 'var(--md-sys-color-primary)',
        color: 'var(--md-sys-color-on-primary)',
      }}
    >
      {MODE_LABELS[roomMode]}
    </div>
  )

  // 右侧评论/弹幕面板：
  // - 非全屏：固定宽度侧边栏（320px），独立卡片式设计（圆角 + 边框 + 阴影）。
  //   高度通过外层 absolute 容器 h-full 与左侧视频严格等高；动画由父容器
  //   的 translateX 与占位区 width 共同完成，避免直接对 panel 做 width/scale。
  // - 原生全屏：悬浮卡片从右侧滑入，带圆角和强阴影。
  const rightPanelNode = (
    <div
      className={cn(
        'flex min-h-0 min-w-0 flex-col overflow-hidden',
        isNativeFullscreen
          ? 'glass-strong absolute inset-y-0 right-0 z-20 w-[85%] max-w-[340px] rounded-l-2xl border-l transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]'
          : 'glass-card h-full w-full rounded-xl',
        isNativeFullscreen && !isRightPanelOpen && 'translate-x-full'
      )}
      style={{
        boxShadow: isNativeFullscreen
          ? '0 8px 32px -4px rgba(0, 0, 0, 0.3)'
          : '0 4px 24px -6px color-mix(in srgb, var(--md-sys-color-shadow) 22%, transparent), 0 0 0 1px color-mix(in srgb, var(--md-sys-color-outline-variant) 50%, transparent)',
        backfaceVisibility: 'hidden',
      }}
    >
      {effectiveRightPanel}
    </div>
  )

  // 展开 Fragment，收集真实子节点，确保 controls 传入 Fragment 时仍能分成独立卡片
  function flattenChildren(node: ReactNode): ReactNode[] {
    return Children.toArray(node).flatMap((child) => {
      if (isValidElement(child) && child.type === Fragment) {
        return flattenChildren(child.props.children)
      }
      return [child]
    })
  }

  return (
    <div className="flex min-h-[calc(100vh-64px)] flex-col items-center overflow-y-auto px-4 py-6">
      <Card className="relative flex w-full max-w-6xl flex-none flex-col overflow-hidden min-h-0 bg-transparent">
        {/* 顶部工具栏：返回、模式切换、右侧操作在同一行，避免 absolute 重叠 */}
        <div className="z-30 flex flex-none items-center justify-between gap-2 px-4 pt-4 pb-2">
          <Button
            variant="ghost"
            size="sm"
            disableAnimation
            icon={<ArrowLeft className="h-4 w-4" />}
            onClick={handleBack}
            className="glass flex-shrink-0 border px-3"
            style={{
              borderColor: 'var(--md-sys-color-outline-variant)',
              color: 'var(--md-sys-color-on-surface)',
            }}
          >
            返回
          </Button>

          {/* 顶部模式切换栏（玻璃拟态 + Monet 主题变量，当前模式高亮 primary 色） */}
          <div className="flex flex-1 justify-center px-2">{modeSwitchBar}</div>

          <div className="flex flex-shrink-0 items-center gap-2">
            <button
              onClick={toggleRightPanel}
              aria-label={isRightPanelOpen ? '收起侧栏' : '展开侧栏'}
              aria-expanded={isRightPanelOpen}
              title={isRightPanelOpen ? '收起侧栏' : '展开侧栏'}
              className="glass flex h-9 w-9 items-center justify-center rounded-lg border transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                borderColor: 'var(--md-sys-color-outline-variant)',
                color: isRightPanelOpen
                  ? 'var(--md-sys-color-primary)'
                  : 'var(--md-sys-color-on-surface-variant)',
              }}
            >
              {isRightPanelOpen ? (
                <PanelRightClose className="h-4 w-4" />
              ) : (
                <PanelRight className="h-4 w-4" />
              )}
            </button>
            {headerActions}
          </div>
        </div>

        {title && (
          <Title level={3} className="pt-2 text-center">
            {title}
          </Title>
        )}

        <div
          className="relative mt-4 flex min-h-0 flex-none gap-3 overflow-hidden"
          style={{
            maxHeight: isNativeFullscreen ? undefined : 'calc(100vh - 220px)',
          }}
        >
          {/* 左侧播放器：决定整个容器高度，flex-1 随侧栏开闭平滑改变宽度 */}
          <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
            <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-black">
              {renderMainContent()}
              {isNativeFullscreen && rightPanelNode}
            </div>
          </div>
          {/* 右侧占位区：宽度动画，与绝对定位面板同步滑动，避免左侧播放器跳变 */}
          {!isNativeFullscreen && (
            <div
              className={cn(
                'flex-shrink-0 overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]',
                isRightPanelOpen ? 'w-[320px]' : 'w-0'
              )}
              aria-hidden="true"
            />
          )}
          {/* 右侧面板：绝对定位保持与左侧视频等高，translateX 滑入滑出更流畅 */}
          {!isNativeFullscreen && (
            <div
              className={cn(
                'pointer-events-none absolute top-0 right-0 h-full overflow-hidden transition-transform duration-300 ease-[cubic-bezier(0.32,0.72,0,1)]',
                isRightPanelOpen ? 'translate-x-0' : 'translate-x-full'
              )}
              style={{ willChange: 'transform' }}
            >
              <div className="pointer-events-auto h-full w-[320px] overflow-hidden">
                {rightPanelNode}
              </div>
            </div>
          )}
        </div>
      </Card>

      {effectiveControls && !webFullscreen && !isNativeFullscreen && (
        <div className="w-full max-w-6xl flex-none mt-4">
          {(() => {
            const controlChildren = flattenChildren(effectiveControls)
            if (controlChildren.length === 1) {
              // 共享状态下评论区单独在下方时限制高度，避免无限撑开
              return (
                <div className={isSharing ? 'h-[500px]' : 'h-full'}>
                  {controlChildren[0]}
                </div>
              )
            }
            // 三个控制卡片固定等高，内部内容各自滚动，避免某个卡片展开/撑高影响整体布局
            return (
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 h-[340px]">
                {controlChildren.map((child, index) => (
                  <Fragment key={index}>{child}</Fragment>
                ))}
              </div>
            )
          })()}
        </div>
      )}
    </div>
  )
}
