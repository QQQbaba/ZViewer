import { useCallback, useEffect, useRef, useState } from 'react'
import {
  Link2,
  QrCode,
  LogOut,
  FileVideo,
  User,
  Plus,
  Search,
  Crown,
  FolderOpen,
  Settings2,
  ChevronDown,
} from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Dropdown } from '@/components/ui/Dropdown'
import { Space } from '@/components/ui/Space'
import { Text, Paragraph } from '@/components/ui/Typography'
import { Modal } from '@/components/ui/Modal'
import { Tag } from '@/components/ui/Tag'
import { Select } from '@/components/ui/Select'

import { message } from '@/components/ui/message'
import { useRoomStore } from '@/store/roomStore'
import { useSocket } from '@/hooks/useSocket'
import { BilibiliBangumiSelector } from './BilibiliBangumiSelector'
import { AniSubsSelector } from '@/modules/anisubs/AniSubsSelector'
import {
  resolveAniSubsEpisode,
  buildAniSubsProxyUrl,
  needsAniSubsProxy,
  type AniSubsEpisode,
} from '@/modules/anisubs'
import { KazumiSelector } from '@/modules/kazumi/KazumiSelector'
import {
  resolveKazumiEpisode,
  buildKazumiProxyUrl,
  needsKazumiProxy,
  type KazumiEpisode,
} from '@/modules/kazumi'
import {
  resolveBilibili,
  resolveFTP,
  buildBilibiliVideoUrl,
  buildBilibiliImageProxyUrl,
  getBilibiliQrCode,
  pollBilibiliQrCode,
  getBilibiliLoginStatus,
  getBilibiliUserInfo,
  logoutBilibili,
  type BilibiliUserInfo,
  type ResolvedSource,
  type FTPParams,
} from '@/modules/room/watch-together/resolveSource'
import {
  resolveBilibiliWithOptions,
  filterQualitiesByVip,
} from '@/modules/bilibili/bilibiliApi'
import {
  useBilibiliParsePreferences,
  setBilibiliParseOptions,
  type BilibiliCodec,
} from '@/modules/bilibili/parseOptions'
import {
  resolveOpenList,
  buildOpenListProxyUrl,
} from '@/modules/openlist/openlistApi'
import OpenListBrowser from '@/modules/openlist/OpenListBrowser'
import { resolveWebDAV, buildWebDAVProxyUrl } from '@/modules/webdav/webdavApi'
import MountBrowser from '@/modules/mounts/MountBrowser'
import WebDAVBrowser from '@/modules/webdav/WebDAVBrowser'
import { resolveFTP as resolveFTPNew } from '@/modules/ftp/ftpApi'
import ServerFilesBrowser from '@/modules/server-files/ServerFilesBrowser'
import {
  resolveServerFile,
  buildServerFileProxyUrl,
} from '@/modules/server-files/serverFilesApi'
import type { MediaFormat } from '@/lib/mediaFormat'
import {
  fetchAllMounts,
  type UnionMount,
  type MountType,
} from '@/modules/mounts'
import { useAuthStore } from '@/store/authStore'
import { useSystemSettingsStore } from '@/store/systemSettingsStore'
import { cn } from '@/lib/utils'

type SourceType = 'bilibili' | 'mp4' | 'webdav' | 'ftp' | 'openlist' | 'anime' | 'kazumi' | 'server-files'

const ALL_SOURCE_OPTIONS: { value: string; label: string; rootOnly?: boolean }[] = [
  { value: 'bilibili', label: '哔哩哔哩' },
  { value: 'mp4', label: 'MP4 直链' },
  { value: 'webdav', label: 'WebDAV' },
  { value: 'ftp', label: 'FTP' },
  { value: 'openlist', label: 'OpenList' },
  { value: 'anime', label: 'ani-subs 番剧源' },
  { value: 'kazumi', label: 'Kazumi 番剧源' },
  { value: 'server-files', label: '服务器文件', rootOnly: true },
]

function extractTitleFromUrl(url: string) {
  try {
    const pathname = new URL(url).pathname
    const filename = pathname.split('/').pop() || url
    return decodeURIComponent(filename)
  } catch {
    return url
  }
}

function normalizeMountPath(path: string): string {
  if (!path) return path
  return path.trim().replace(/^\/+/, '/')
}

interface MoviePushPanelProps {
  isHost: boolean
}

/**
 * B站解析设置子组件：编码格式 + 播放模式。
 *
 * 折叠展开式，默认收起。修改后立即写入 localStorage 持久化，
 * 并通过 triggerReloadBilibili 触发当前 B站 影片的重新解析（应用新偏好）。
 * 所有 B站 影片共享同一份解析偏好（localStorage 单 key 存储）。
 *
 * 解析偏好通过 useBilibiliParsePreferences hook 跨组件同步：
 * MovieListPanel 读取 preferMp4 用于禁用分辨率 Select。
 *
 * 仅当当前播放的影片为 bilibili 源时才触发重载，避免无关影片受影响。
 */
function BilibiliParseSettings() {
  const [expanded, setExpanded] = useState(false)
  const { codec, preferMp4 } = useBilibiliParsePreferences()
  const triggerReloadBilibili = useRoomStore(
    (state) => state.triggerReloadBilibili
  )
  const currentMovieId = useRoomStore((state) => state.currentMovieId)
  const movies = useRoomStore((state) => state.movies)

  // 当前播放的影片是否为 B站 源：是则修改偏好后触发重载
  const currentMovieIsBilibili =
    currentMovieId != null &&
    movies.some((m) => m.id === currentMovieId && m.sourceType === 'bilibili')

  const handleCodecChange = useCallback(
    (value: string) => {
      const next = value as BilibiliCodec
      setBilibiliParseOptions({ codec: next })
      if (currentMovieIsBilibili) {
        triggerReloadBilibili()
      }
    },
    [currentMovieIsBilibili, triggerReloadBilibili]
  )

  const handlePreferMp4Change = useCallback(
    (next: boolean) => {
      setBilibiliParseOptions({ preferMp4: next })
      if (currentMovieIsBilibili) {
        triggerReloadBilibili()
      }
    },
    [currentMovieIsBilibili, triggerReloadBilibili]
  )

  return (
    <div className="w-full">
      <button
        type="button"
        onClick={() => setExpanded((prev) => !prev)}
        className="flex w-full items-center justify-between rounded-[var(--md-sys-shape-corner)] px-1.5 py-1 text-[10px] transition-colors hover:bg-[var(--md-sys-color-surface-container-highest)]"
        style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
        aria-expanded={expanded}
      >
        <span className="flex items-center gap-1">
          <Settings2 className="h-3 w-3" />
          B站解析设置
        </span>
        <ChevronDown
          className={cn(
            'h-3 w-3 transition-transform',
            expanded && 'rotate-180'
          )}
        />
      </button>
      {expanded && (
        <div className="glass flex flex-col gap-1.5 rounded-[var(--md-sys-shape-corner)] p-1.5">
          <Select
            label="编码格式"
            size="sm"
            options={[
              { label: '自动', value: 'auto' },
              { label: 'H.264', value: 'avc' },
              { label: 'HEVC', value: 'hevc' },
              { label: 'AV1', value: 'av1' },
            ]}
            value={codec}
            onChange={handleCodecChange}
          />
          <div>
            <div
              className="mb-0.5 text-[10px] font-medium uppercase tracking-wide"
              style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
            >
              播放模式
            </div>
            <div className="grid grid-cols-2 gap-1">
              <button
                type="button"
                onClick={() => handlePreferMp4Change(false)}
                className={cn(
                  'rounded-md py-0.5 text-[10px] font-medium transition-all',
                  !preferMp4
                    ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                    : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-highest)]'
                )}
              >
                DASH 高清
              </button>
              <button
                type="button"
                onClick={() => handlePreferMp4Change(true)}
                className={cn(
                  'rounded-md py-0.5 text-[10px] font-medium transition-all',
                  preferMp4
                    ? 'bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] shadow-sm'
                    : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-highest)]'
                )}
              >
                MP4 流畅
              </button>
            </div>
            <div
              className="mt-0.5 text-[9px] leading-tight"
              style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
            >
              {preferMp4
                ? 'MP4 直链，seek 流畅，清晰度通常 480P/720P'
                : 'DASH 分离流，支持 1080P/4K，seek 需缓冲'}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function MoviePushPanel({ isHost }: MoviePushPanelProps) {
  const { socket } = useSocket()
  const userRole = useAuthStore((state) => state.user?.role)
  const { betaFeaturesEnabled, fetchSettings } = useSystemSettingsStore()
  const addMovie = useRoomStore((state) => state.addMovie)
  const fetchMovies = useRoomStore((state) => state.fetchMovies)
  const setCurrentMovieId = useRoomStore((state) => state.setCurrentMovieId)
  const setPendingPreviewPlay = useRoomStore(
    (state) => state.setPendingPreviewPlay
  )
  const roomId = useRoomStore((state) => state.roomId)
  // 读取播放模式偏好：MP4 模式下禁用分辨率 Dropdown
  // （B站 MP4 直链通常仅支持 480P/720P，DASH 才支持 1080P/4K，无需也不能切换）
  const { preferMp4 } = useBilibiliParsePreferences()
  const [sourceType, setSourceType] = useState<SourceType>('bilibili')
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [qualityLoading, setQualityLoading] = useState(false)
  const [resolvedMovie, setResolvedMovie] = useState<ResolvedSource | null>(
    null
  )
  // B站 解析进度：在推送面板也展示后台解析过程
  const [resolveProgress, setResolveProgress] = useState<string>('')

  // WebDAV / FTP / OpenList 表单状态
  const [webdav, setWebdav] = useState<{
    serverUrl: string
    path: string
  }>({
    serverUrl: '',
    path: '',
  })
  const [webdavDirectLink, setWebdavDirectLink] = useState(false)
  const [ftp, setFtp] = useState<FTPParams>({
    serverUrl: '',
    path: '',
    port: 21,
    username: '',
    password: '',
  })
  const [openlist, setOpenlist] = useState<{
    serverUrl: string
    path: string
  }>({
    serverUrl: '',
    path: '',
  })

  // 已保存挂载
  const [mounts, setMounts] = useState<UnionMount[]>([])
  const [selectedMountId, setSelectedMountId] = useState<string>('')
  const [browsingMount, setBrowsingMount] = useState<UnionMount | null>(null)

  const [bilibiliLoggedIn, setBilibiliLoggedIn] = useState(false)
  const [bilibiliUser, setBilibiliUser] = useState<BilibiliUserInfo | null>(
    null
  )
  const [avatarError, setAvatarError] = useState(false)
  const [bangumiOpen, setBangumiOpen] = useState(false)
  const [animeOpen, setAnimeOpen] = useState(false)
  const [kazumiOpen, setKazumiOpen] = useState(false)
  const [serverFilesBrowserOpen, setServerFilesBrowserOpen] = useState(false)
  const [serverFilePath, setServerFilePath] = useState('')
  const [qrModalOpen, setQrModalOpen] = useState(false)
  const [qrDataUrl, setQrDataUrl] = useState('')
  const [qrStatus, setQrStatus] = useState(0)
  const [qrMessage, setQrMessage] = useState('请使用哔哩哔哩 App 扫码登录')
  const pollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const isPollingRef = useRef(false)
  const qrRetryCountRef = useRef(0)

  useEffect(() => {
    void fetchSettings()
  }, [fetchSettings])

  useEffect(() => {
    if (!betaFeaturesEnabled && (sourceType === 'anime' || sourceType === 'kazumi')) {
      setSourceType('bilibili')
    }
  }, [betaFeaturesEnabled, sourceType])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- sourceType 变化时重置状态
    setResolvedMovie(null)
    setOpenlist({ serverUrl: '', path: '' })
    setSelectedMountId('')
    if (sourceType !== 'bilibili') return
    getBilibiliLoginStatus().then((loggedIn) => {
      setBilibiliLoggedIn(loggedIn)
      if (loggedIn) {
        getBilibiliUserInfo().then((info) => {
          if (info) setBilibiliUser(info)
        })
      } else {
        setBilibiliUser(null)
      }
    })
  }, [sourceType])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- 头像变化时重置错误状态
    setAvatarError(false)
  }, [bilibiliUser?.avatar])

  const stopQrPolling = useCallback(() => {
    isPollingRef.current = false
    if (pollTimerRef.current) {
      clearTimeout(pollTimerRef.current)
      pollTimerRef.current = null
    }
  }, [])

  const startQrPolling = useCallback(
    (key: string) => {
      if (isPollingRef.current) return
      isPollingRef.current = true
      qrRetryCountRef.current = 0

      const poll = async () => {
        if (!isPollingRef.current) return
        try {
          const result = await pollBilibiliQrCode(key)
          qrRetryCountRef.current = 0
          setQrStatus(result.status)
          if (result.status === 0) {
            setQrMessage('请使用哔哩哔哩 App 扫码登录')
          } else if (result.status === 1) {
            setQrMessage('已扫码，请在 App 中确认登录')
          } else if (result.status === 2) {
            setQrMessage('登录成功')
            setBilibiliLoggedIn(true)
            const info = await getBilibiliUserInfo()
            if (info) setBilibiliUser(info)
            setQrModalOpen(false)
            message.success('B站 登录成功')
            stopQrPolling()
            return
          } else if (result.status === 3) {
            setQrMessage('二维码已过期，请重新获取')
            stopQrPolling()
            return
          }
          pollTimerRef.current = setTimeout(poll, 2000)
        } catch (err) {
          console.error('[MoviePushPanel] QR poll error:', err)
          qrRetryCountRef.current += 1
          if (qrRetryCountRef.current <= 2) {
            setQrMessage('轮询状态失败，正在重试…')
            pollTimerRef.current = setTimeout(poll, 2000)
          } else {
            setQrMessage('轮询状态失败，请重新获取')
            stopQrPolling()
          }
        }
      }

      void poll()
    },
    [stopQrPolling]
  )

  const handleOpenQrModal = useCallback(async () => {
    stopQrPolling()
    setQrStatus(0)
    setQrMessage('请使用哔哩哔哩 App 扫码登录')
    setQrModalOpen(true)
    try {
      const data = await getBilibiliQrCode()
      setQrDataUrl(data.qrDataUrl)
      startQrPolling(data.qrcodeKey)
    } catch (err) {
      message.error(err instanceof Error ? err.message : '获取二维码失败')
      setQrModalOpen(false)
    }
  }, [stopQrPolling, startQrPolling])

  const handleCloseQrModal = useCallback(() => {
    stopQrPolling()
    setQrModalOpen(false)
  }, [stopQrPolling])

  const handleLogoutBilibili = useCallback(async () => {
    try {
      await logoutBilibili()
      setBilibiliLoggedIn(false)
      setBilibiliUser(null)
      message.success('已退出 B站 登录')
    } catch {
      message.error('退出登录失败')
    }
  }, [])

  const handleSelectBangumiEpisode = useCallback(
    async (bvid: string, cid: number, title: string) => {
      if (!isHost) {
        message.info('只有房主可以播放影片')
        return
      }
      if (!roomId) {
        message.error('未连接房间')
        return
      }

      const videoUrl = buildBilibiliVideoUrl(bvid)
      setLoading(true)
      try {
        const resolved = await resolveBilibili(videoUrl)
        await addMovie(roomId, {
          url: videoUrl,
          title: title || resolved.title || videoUrl,
          source: 'bilibili',
          audioUrl: resolved.audioUrl,
          format: resolved.format,
          videoCodec: resolved.videoCodec,
          audioCodec: resolved.audioCodec,
          duration: resolved.duration,
          cid: cid || resolved.cid,
          currentQn: resolved.currentQn,
          acceptQuality: resolved.acceptQuality,
        })
        await fetchMovies(roomId)
        const movie = useRoomStore
          .getState()
          .movies.find((m) => m.url === videoUrl)
        if (movie) {
          setCurrentMovieId(movie.id)
          socket?.emit('play-movie', { roomId, movieId: movie.id })
        }
        message.success('已加载番剧集数')
      } catch (err) {
        console.error('[MoviePushPanel] select bangumi episode error:', err)
        message.error(err instanceof Error ? err.message : '加载番剧集数失败')
      } finally {
        setLoading(false)
      }
    },
    [isHost, roomId, addMovie, fetchMovies, setCurrentMovieId, socket]
  )

  const handleSelectAnimeEpisode = useCallback(
    async (sourceId: string, episode: AniSubsEpisode, title: string) => {
      if (!isHost) {
        message.info('只有房主可以播放影片')
        return
      }
      if (!roomId) {
        message.error('未连接房间')
        return
      }

      setLoading(true)
      try {
        const resolved = await resolveAniSubsEpisode(sourceId, episode)

        // 防盗链处理：若返回 headers（Referer/UA 等），走后端代理 URL
        // 浏览器无法为 video.src 设置 Referer/UA，必须代理
        const finalUrl = needsAniSubsProxy(resolved.url, resolved.headers)
          ? buildAniSubsProxyUrl(resolved.url, resolved.headers)
          : resolved.url

        // 1. 触发实时预览播放（通过 store 解耦 useWatchTogether）
        //    代理 URL 已包含防盗链信息，无需再传 headers
        setPendingPreviewPlay({
          url: finalUrl,
          title,
          sourceType: 'anime',
          format: resolved.format,
        })

        // 2. 同时异步加入影片列表（不阻塞预览播放）
        //    后端广播 movie-list 后由 useWatchTogether 自动刷新本地缓存
        void addMovie(roomId, {
          url: finalUrl,
          title,
          source: 'anime',
          format: resolved.format,
        })
          .then(() => fetchMovies(roomId))
          .catch((err) => {
            console.error(
              '[MoviePushPanel] addMovie/fetchMovies after preview failed:',
              err
            )
          })

        message.success('已开始播放并加入列表')
      } catch (err) {
        console.error('[MoviePushPanel] select anime episode error:', err)
        message.error(err instanceof Error ? err.message : '加载番剧集数失败')
      } finally {
        setLoading(false)
      }
    },
    [isHost, roomId, addMovie, fetchMovies, setPendingPreviewPlay]
  )

  const handleSelectKazumiEpisode = useCallback(
    async (sourceId: string, episode: KazumiEpisode, title: string) => {
      if (!isHost) {
        message.info('只有房主可以播放影片')
        return
      }
      if (!roomId) {
        message.error('未连接房间')
        return
      }

      setLoading(true)
      try {
        const resolved = await resolveKazumiEpisode(sourceId, episode)

        const finalUrl = needsKazumiProxy(resolved.url, resolved.headers)
          ? buildKazumiProxyUrl(resolved.url, resolved.headers)
          : resolved.url

        setPendingPreviewPlay({
          url: finalUrl,
          title,
          sourceType: 'kazumi',
          format: resolved.format,
        })

        void addMovie(roomId, {
          url: finalUrl,
          title,
          source: 'kazumi',
          format: resolved.format,
        })
          .then(() => fetchMovies(roomId))
          .catch((err) => {
            console.error(
              '[MoviePushPanel] addMovie/fetchMovies after kazumi preview failed:',
              err
            )
          })

        message.success('已开始播放并加入列表')
      } catch (err) {
        console.error('[MoviePushPanel] select kazumi episode error:', err)
        message.error(err instanceof Error ? err.message : '加载番剧集数失败')
      } finally {
        setLoading(false)
      }
    },
    [isHost, roomId, addMovie, fetchMovies, setPendingPreviewPlay]
  )

  useEffect(() => {
    fetchAllMounts()
      .then((data) => setMounts(data))
      .catch((err) => {
        console.error('[MoviePushPanel] fetch mounts error:', err)
      })
  }, [])

  useEffect(() => {
    return () => {
      stopQrPolling()
    }
  }, [stopQrPolling])

  const handleMountSelect = (value: string) => {
    setSelectedMountId(value)
    const id = Number(value)
    if (!id) return
    const mount = mounts.find((m) => m.id === id)
    if (!mount) return
    if (sourceType === 'webdav') {
      setWebdav({
        serverUrl: mount.serverUrl || '',
        path: normalizeMountPath(mount.path || ''),
      })
      setWebdavDirectLink(mount.directLink)
    } else if (sourceType === 'ftp') {
      setFtp((prev) => ({
        ...prev,
        serverUrl: mount.serverUrl || '',
        port: mount.port ?? 21,
        path: normalizeMountPath(mount.path || ''),
        username: mount.username || '',
        // 密码由后端挂载配置内部管理，列表接口不返回密码
        password: '',
      }))
    } else if (sourceType === 'openlist') {
      setOpenlist({
        serverUrl: mount.serverUrl || '',
        path: normalizeMountPath(mount.path || ''),
      })
    }
  }

  const handleSelectFilesFromMount = useCallback(
    async (paths: string[]) => {
      if (!isHost) {
        message.info('只有房主可以添加影片')
        return
      }
      if (!roomId) {
        message.error('未连接房间')
        return
      }

      const mountId = Number(selectedMountId)
      if (!mountId) {
        message.warning('请选择已保存的挂载')
        return
      }

      setLoading(true)
      setResolveProgress(`正在批量解析 ${paths.length} 个文件...`)
      try {
        let added = 0
        for (const path of paths) {
          const normalizedPath = normalizeMountPath(path)
          if (sourceType === 'webdav') {
            const resolved = await resolveWebDAV(mountId, normalizedPath)
            const title = resolved.title || extractTitleFromUrl(normalizedPath)
            const movieUrl = buildWebDAVProxyUrl(mountId, normalizedPath)
            await addMovie(roomId, {
              url: movieUrl,
              title,
              source: 'webdav',
              format: resolved.format,
              duration: resolved.duration,
              serverUrl: webdav.serverUrl.trim() || undefined,
              path: normalizedPath,
              directLink: webdavDirectLink,
            })
            added++
          } else if (sourceType === 'ftp') {
            const resolved = await resolveFTPNew(mountId, normalizedPath)
            const title = resolved.title || extractTitleFromUrl(normalizedPath)
            await addMovie(roomId, {
              url: resolved.videoUrl,
              title,
              source: 'ftp',
              format: resolved.format,
              serverUrl: ftp.serverUrl.trim(),
              path: normalizedPath,
              username: ftp.username || undefined,
              password: ftp.password || undefined,
            })
            added++
          } else if (sourceType === 'openlist') {
            const resolved = await resolveOpenList(mountId, normalizedPath)
            const title = resolved.title || extractTitleFromUrl(normalizedPath)
            const movieUrl = buildOpenListProxyUrl(mountId, normalizedPath)
            await addMovie(roomId, {
              url: movieUrl,
              title,
              source: 'openlist',
              format: resolved.format,
              duration: resolved.duration,
              serverUrl: openlist.serverUrl.trim() || undefined,
              path: normalizedPath,
              directLink: false,
            })
            added++
          }
        }
        message.success(`已添加 ${added} 部影片`)
      } catch (err) {
        console.error('[MoviePushPanel] batch add error:', err)
        message.error(err instanceof Error ? err.message : '批量添加失败')
      } finally {
        setLoading(false)
        setResolveProgress('')
      }
    },
    [
      isHost,
      roomId,
      selectedMountId,
      sourceType,
      webdav.serverUrl,
      webdavDirectLink,
      ftp.serverUrl,
      ftp.username,
      ftp.password,
      openlist.serverUrl,
    ]
  )

  const resetForm = () => {
    setUrl('')
    setResolvedMovie(null)
    setSelectedMountId('')
    setWebdav({ serverUrl: '', path: '' })
    setWebdavDirectLink(false)
    setFtp({ serverUrl: '', path: '', port: 21, username: '', password: '' })
    setOpenlist({ serverUrl: '', path: '' })
    setServerFilePath('')
  }

  // 仅 bilibili 需要 handleResolve：解析后显示清晰度选择器，再点"添加"
  // webdav/ftp/openlist/mp4 的 resolve+add 已合并到 handleAddMovie
  const handleResolve = async () => {
    if (!isHost) {
      message.info('只有房主可以添加影片')
      return
    }
    if (!roomId) {
      message.error('未连接房间')
      return
    }
    if (sourceType !== 'bilibili') return
    if (!url.trim()) {
      message.warning('请输入视频地址')
      return
    }

    setLoading(true)
    setResolveProgress('正在初始化解析...')
    try {
      const resolved = await resolveBilibili(
        url.trim(),
        undefined,
        (_step, msg) => setResolveProgress(msg)
      )
      setResolvedMovie(resolved)
    } catch (err) {
      console.error('[MoviePushPanel] resolve error:', err)
      message.error(err instanceof Error ? err.message : '解析失败')
    } finally {
      setLoading(false)
      setResolveProgress('')
    }
  }

  const handleQualityChange = async (selectedQn: string) => {
    if (!resolvedMovie || !url.trim()) return
    const qn = Number(selectedQn)
    if (!Number.isFinite(qn)) return

    setQualityLoading(true)
    setResolveProgress('正在切换清晰度...')
    try {
      const resolved = await resolveBilibiliWithOptions(
        url.trim(),
        qn,
        (_step, msg) => setResolveProgress(msg)
      )
      setResolvedMovie(resolved)
    } catch (err) {
      console.error('[MoviePushPanel] switch quality error:', err)
      message.error(err instanceof Error ? err.message : '切换清晰度失败')
    } finally {
      setQualityLoading(false)
      setResolveProgress('')
    }
  }

  // 统一添加影片：对 webdav/ftp/openlist/mp4 合并 resolve+add 为单步操作
  // bilibili 仍走两步：先 handleResolve 解析 → 选清晰度 → handleAddMovie 添加
  const handleAddMovie = async () => {
    if (!isHost) {
      message.info('只有房主可以添加影片')
      return
    }
    if (!roomId) {
      message.error('未连接房间')
      return
    }

    setLoading(true)
    setResolveProgress('正在添加影片...')
    try {
      if (sourceType === 'bilibili' && resolvedMovie) {
        const title = resolvedMovie.title || url.trim()
        await addMovie(roomId, {
          url: url.trim(),
          title,
          source: 'bilibili',
          audioUrl: resolvedMovie.audioUrl,
          format: resolvedMovie.format,
          videoCodec: resolvedMovie.videoCodec,
          audioCodec: resolvedMovie.audioCodec,
          duration: resolvedMovie.duration,
          cid: resolvedMovie.cid,
          currentQn: resolvedMovie.currentQn,
          acceptQuality: resolvedMovie.acceptQuality,
          pages: resolvedMovie.pages,
          currentPage: resolvedMovie.currentPage ?? 1,
        })
        resetForm()
        message.success('影片已添加')
      } else if (sourceType === 'mp4') {
        if (!url.trim()) {
          message.warning('请输入视频地址')
          return
        }
        const movieUrl = url.trim()
        const title = extractTitleFromUrl(movieUrl)
        await addMovie(roomId, { url: movieUrl, title, source: 'mp4' })
        resetForm()
        message.success('影片已添加')
      } else if (sourceType === 'webdav') {
        if (!webdav.path.trim()) {
          message.warning('请填写文件路径')
          return
        }
        let title: string
        let movieUrl: string
        let format: MediaFormat = 'mp4'
        let duration: number | undefined

        if (webdavDirectLink) {
          if (!webdav.serverUrl.trim()) {
            message.warning('请填写服务器地址')
            return
          }
          movieUrl = `${webdav.serverUrl.trim()}${webdav.path.trim()}`
          title = extractTitleFromUrl(webdav.path.trim())
        } else {
          const mountId = Number(selectedMountId)
          if (!mountId) {
            message.warning('请选择已保存的 WebDAV 挂载')
            return
          }
          setResolveProgress('正在解析 WebDAV 文件...')
          const resolved = await resolveWebDAV(mountId, webdav.path.trim())
          title = resolved.title || extractTitleFromUrl(webdav.path.trim())
          movieUrl = buildWebDAVProxyUrl(mountId, webdav.path.trim())
          format = resolved.format
          duration = resolved.duration
        }
        await addMovie(roomId, {
          url: movieUrl,
          title,
          source: 'webdav',
          format,
          duration,
          serverUrl: webdav.serverUrl.trim() || undefined,
          path: webdav.path.trim(),
          directLink: webdavDirectLink,
        })
        resetForm()
        message.success('影片已添加')
      } else if (sourceType === 'ftp') {
        if (!ftp.serverUrl.trim() || !ftp.path.trim()) {
          message.warning('请填写服务器地址与路径')
          return
        }
        setResolveProgress('正在解析 FTP 文件...')
        // 优先使用已保存挂载的新 API；手动填写时回退到旧 API
        const mountId = Number(selectedMountId)
        let title: string
        let movieUrl: string
        let format: MediaFormat = 'mp4'

        if (mountId) {
          const resolved = await resolveFTPNew(mountId, ftp.path.trim())
          title = resolved.title || extractTitleFromUrl(ftp.path.trim())
          movieUrl = resolved.videoUrl
          format = resolved.format
        } else {
          const resolved = await resolveFTP({
            serverUrl: ftp.serverUrl.trim(),
            path: ftp.path.trim(),
            port: ftp.port,
            username: ftp.username || undefined,
            password: ftp.password || undefined,
          })
          title = resolved.title || extractTitleFromUrl(ftp.path.trim())
          movieUrl = resolved.videoUrl
          format = resolved.format
        }
        await addMovie(roomId, {
          url: movieUrl,
          title,
          source: 'ftp',
          format,
          serverUrl: ftp.serverUrl.trim(),
          path: ftp.path.trim(),
          username: ftp.username || undefined,
          password: ftp.password || undefined,
        })
        resetForm()
        message.success('影片已添加')
      } else if (sourceType === 'openlist') {
        if (!openlist.path.trim()) {
          message.warning('请填写文件路径')
          return
        }
        const mountId = Number(selectedMountId)
        if (!mountId) {
          message.warning('请选择已保存的 OpenList 挂载')
          return
        }
        setResolveProgress('正在解析 OpenList 文件...')
        const resolved = await resolveOpenList(mountId, openlist.path.trim())
        const title =
          resolved.title || extractTitleFromUrl(openlist.path.trim())
        const movieUrl = buildOpenListProxyUrl(mountId, openlist.path.trim())
        await addMovie(roomId, {
          url: movieUrl,
          title,
          source: 'openlist',
          format: resolved.format,
          duration: resolved.duration,
          serverUrl: openlist.serverUrl.trim() || undefined,
          path: openlist.path.trim(),
          directLink: false,
        })
        resetForm()
        message.success('影片已添加')
      } else if (sourceType === 'server-files') {
        if (!serverFilePath.trim()) {
          message.warning('请选择服务器文件')
          return
        }
        setResolveProgress('正在解析服务器文件...')
        const resolved = await resolveServerFile(serverFilePath.trim())
        const movieUrl = buildServerFileProxyUrl(serverFilePath.trim())
        await addMovie(roomId, {
          url: movieUrl,
          title: resolved.title,
          source: 'server-files',
          format: resolved.format as MediaFormat,
          path: serverFilePath.trim(),
        })
        resetForm()
        message.success('影片已添加')
      }
    } catch (err) {
      console.error('[MoviePushPanel] add movie error:', err)
      message.error(err instanceof Error ? err.message : '添加影片失败')
    } finally {
      setLoading(false)
      setResolveProgress('')
    }
  }

  // bilibili 需要先解析再选清晰度；anime 有独立搜索弹窗；其他源点击"添加"直接 resolve+add
  const renderActionButton = () => {
    if (sourceType === 'anime') {
      return (
        <Button
          variant="primary"
          size="md"
          block
          loading={loading}
          icon={<Search className="h-4 w-4" />}
          onClick={() => setAnimeOpen(true)}
          disabled={!isHost}
        >
          搜索番剧
        </Button>
      )
    }

    if (sourceType === 'kazumi') {
      return (
        <Button
          variant="primary"
          size="md"
          block
          loading={loading}
          icon={<Search className="h-4 w-4" />}
          onClick={() => setKazumiOpen(true)}
          disabled={!isHost}
        >
          搜索番剧
        </Button>
      )
    }

    if (sourceType === 'bilibili') {
      if (resolvedMovie) {
        return (
          <Button
            variant="primary"
            size="md"
            block
            loading={loading}
            icon={<Plus className="h-4 w-4" />}
            onClick={handleAddMovie}
            disabled={!isHost}
          >
            添加
          </Button>
        )
      }
      return (
        <Button
          variant="primary"
          size="md"
          block
          loading={loading}
          icon={<Link2 className="h-4 w-4" />}
          onClick={() => void handleResolve()}
          disabled={!isHost}
        >
          解析
        </Button>
      )
    }

    // mp4 / webdav / ftp / openlist：单步"添加"
    return (
      <Button
        variant="primary"
        size="md"
        block
        loading={loading}
        icon={<Plus className="h-4 w-4" />}
        onClick={() => void handleAddMovie()}
        disabled={!isHost}
      >
        添加
      </Button>
    )
  }

  const renderSourceForm = () => {
    const getMountOptions = (type: MountType) => [
      { value: '', label: '手动填写' },
      ...mounts
        .filter((m) => m.type === type)
        .map((m) => ({ value: String(m.id), label: m.name })),
    ]

    if (sourceType === 'bilibili' || sourceType === 'mp4') {
      return (
        <Input
          size="sm"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder={
            sourceType === 'bilibili'
              ? '视频 Url 或 bv 号'
              : 'MP4/WebM 等视频直链'
          }
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              // bilibili 走解析流程，mp4 直接添加
              void (sourceType === 'bilibili'
                ? handleResolve()
                : handleAddMovie())
            }
          }}
        />
      )
    }

    if (sourceType === 'webdav') {
      return (
        <Space direction="vertical" className="w-full" size="sm">
          <Dropdown
            label="使用已保存的 WebDAV 挂载"
            value={selectedMountId}
            options={getMountOptions('webdav')}
            onChange={handleMountSelect}
          />
          {selectedMountId && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                const mount = mounts.find(
                  (m) => m.id === Number(selectedMountId)
                )
                if (mount) setBrowsingMount(mount)
              }}
            >
              浏览文件
            </Button>
          )}
          <Input
            size="sm"
            value={webdav.serverUrl}
            onChange={(e) =>
              setWebdav((prev) => ({ ...prev, serverUrl: e.target.value }))
            }
            placeholder="WebDAV 服务器地址，如 https://example.com/dav（直链模式必填）"
          />
          <Input
            size="sm"
            value={webdav.path}
            onChange={(e) =>
              setWebdav((prev) => ({
                ...prev,
                path: normalizeMountPath(e.target.value),
              }))
            }
            placeholder="文件路径，如 /movies/video.mp4"
          />
          <Dropdown
            value={webdavDirectLink ? 'direct' : 'proxy'}
            options={[
              { value: 'proxy', label: '服务器转发' },
              { value: 'direct', label: '直链直连' },
            ]}
            onChange={(value) => setWebdavDirectLink(value === 'direct')}
          />
        </Space>
      )
    }

    if (sourceType === 'ftp') {
      return (
        <Space direction="vertical" className="w-full" size="sm">
          <Dropdown
            label="使用已保存的 FTP 挂载"
            value={selectedMountId}
            options={getMountOptions('ftp')}
            onChange={handleMountSelect}
          />
          {selectedMountId && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                const mount = mounts.find(
                  (m) => m.id === Number(selectedMountId)
                )
                if (mount) setBrowsingMount(mount)
              }}
            >
              浏览文件
            </Button>
          )}
          <Input
            size="sm"
            value={ftp.serverUrl}
            onChange={(e) =>
              setFtp((prev) => ({ ...prev, serverUrl: e.target.value }))
            }
            placeholder="FTP 服务器地址，如 ftp.example.com"
          />
          <Input
            size="sm"
            type="number"
            value={String(ftp.port)}
            onChange={(e) =>
              setFtp((prev) => ({
                ...prev,
                port: Number(e.target.value) || 21,
              }))
            }
            placeholder="端口，默认 21"
          />
          <Input
            size="sm"
            value={ftp.path}
            onChange={(e) =>
              setFtp((prev) => ({
                ...prev,
                path: normalizeMountPath(e.target.value),
              }))
            }
            placeholder="文件路径，如 /movies/video.mp4"
          />
          <Input
            size="sm"
            value={ftp.username}
            onChange={(e) =>
              setFtp((prev) => ({ ...prev, username: e.target.value }))
            }
            placeholder="用户名（可选）"
          />
          <Input
            size="sm"
            type="password"
            value={ftp.password}
            onChange={(e) =>
              setFtp((prev) => ({ ...prev, password: e.target.value }))
            }
            placeholder="密码（可选）"
          />
        </Space>
      )
    }

    if (sourceType === 'anime') {
      return (
        <div className="rounded-[var(--md-sys-shape-corner)] border border-[var(--md-sys-color-outline)] bg-[var(--glass-bg)] p-3">
          <Text className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
            从 ani-subs 订阅源搜索番剧并选择集数播放。
          </Text>
        </div>
      )
    }

    if (sourceType === 'kazumi') {
      return (
        <div className="rounded-[var(--md-sys-shape-corner)] border border-[var(--md-sys-color-outline)] bg-[var(--glass-bg)] p-3">
          <Text className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
            从 Kazumi XPath 规则源搜索番剧并选择集数播放。
          </Text>
        </div>
      )
    }

    if (sourceType === 'openlist') {
      return (
        <Space direction="vertical" className="w-full" size="sm">
          <Dropdown
            label="使用已保存的 OpenList 挂载"
            value={selectedMountId}
            options={getMountOptions('openlist')}
            onChange={handleMountSelect}
          />
          {selectedMountId && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                const mount = mounts.find(
                  (m) => m.id === Number(selectedMountId)
                )
                if (mount) setBrowsingMount(mount)
              }}
            >
              浏览文件
            </Button>
          )}
          <Input
            size="sm"
            value={openlist.serverUrl}
            onChange={(e) =>
              setOpenlist((prev) => ({ ...prev, serverUrl: e.target.value }))
            }
            placeholder="OpenList 服务器地址（仅手动填写时需要，已选挂载自动填充）"
          />
          <Input
            size="sm"
            value={openlist.path}
            onChange={(e) =>
              setOpenlist((prev) => ({
                ...prev,
                path: normalizeMountPath(e.target.value),
              }))
            }
            placeholder="文件路径，如 /movies/video.mp4"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                void handleAddMovie()
              }
            }}
          />
          {/* OpenList 始终使用服务器转发模式：WebDAV 路径不是可播放直链，
              直连会被浏览器 ORB 策略阻止，必须通过后端代理处理认证与 CORS */}
        </Space>
      )
    }

    if (sourceType === 'server-files') {
      return (
        <Space direction="vertical" className="w-full" size="sm">
          <Button
            variant="secondary"
            size="sm"
            icon={<FolderOpen className="h-4 w-4" />}
            onClick={() => setServerFilesBrowserOpen(true)}
          >
            浏览服务器文件
          </Button>
          <Input
            size="sm"
            value={serverFilePath}
            onChange={(e) => setServerFilePath(e.target.value)}
            placeholder="文件路径，如 /movies/video.mp4（可点击上方按钮选择）"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                void handleAddMovie()
              }
            }}
          />
        </Space>
      )
    }

    return null
  }

  return (
    <>
      <div className="glass-card zen-card flex h-full min-w-0 flex-col overflow-hidden rounded-[var(--md-sys-shape-corner)]">
        {/* 卡片头部：图标 + 标题 */}
        <div className="flex items-center gap-2.5 border-b border-[var(--glass-border)] px-4 py-3">
          <div
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--md-sys-shape-corner)]"
            style={{
              backgroundColor: 'var(--md-sys-color-secondary-container)',
            }}
          >
            <Plus
              className="h-4 w-4"
              style={{ color: 'var(--md-sys-color-on-secondary-container)' }}
            />
          </div>
          <div className="flex min-w-0 flex-1 flex-col">
            <Text className="text-sm font-semibold leading-tight">
              添加影片
            </Text>
            <Text type="secondary" className="text-[10px] uppercase tracking-wide">
              选择来源并添加
            </Text>
          </div>
        </div>

        {/* 卡片内容 */}
        <div className="zen-scroll flex min-h-0 flex-1 flex-col gap-2.5 overflow-y-auto px-4 py-3">
          <Dropdown
            value={sourceType}
            options={ALL_SOURCE_OPTIONS.filter(
              (opt) =>
                (!opt.rootOnly || userRole === 'root') &&
                (betaFeaturesEnabled ||
                  (opt.value !== 'anime' && opt.value !== 'kazumi'))
            )}
            onChange={(value) => setSourceType(value as SourceType)}
          />

          {renderSourceForm()}

          {renderActionButton()}

          {resolveProgress && (
            <div
              className="flex items-center gap-2 rounded-[var(--md-sys-shape-corner)] px-3 py-2 text-xs"
              style={{
                backgroundColor: 'var(--md-sys-color-primary-container)',
                color: 'var(--md-sys-color-on-primary-container)',
              }}
            >
              <span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
              <Text className="text-xs">{resolveProgress}</Text>
            </div>
          )}

          {sourceType === 'bilibili' &&
            resolvedMovie?.acceptQuality &&
            resolvedMovie.acceptQuality.length > 0 && (
              <>
                <Dropdown
                  value={String(
                    resolvedMovie.currentQn ?? resolvedMovie.acceptQuality[0]?.id
                  )}
                  options={filterQualitiesByVip(
                    resolvedMovie.acceptQuality,
                    bilibiliUser?.vipStatus === 1
                  ).map((q) => ({
                    label: q.resolution ? `${q.label} · ${q.resolution}` : q.label,
                    value: String(q.id),
                  }))}
                  onChange={(value) => void handleQualityChange(value)}
                  disabled={qualityLoading || !isHost || preferMp4}
                />
                {preferMp4 && (
                  <div
                    className="text-[9px] leading-tight"
                    style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
                  >
                    MP4 流畅模式下清晰度由 B站 决定，无法手动切换
                  </div>
                )}
              </>
            )}

          {sourceType === 'bilibili' && (
            <div
              className="rounded-[var(--md-sys-shape-corner)] p-2.5"
              style={{
                backgroundColor:
                  'var(--glass-bg)',
              }}
            >
              <div className="flex items-center gap-2">
                <FileVideo
                  className="h-3.5 w-3.5"
                  style={{ color: 'var(--md-sys-color-primary)' }}
                />
                <Text type="secondary" className="text-[10px] uppercase tracking-wide">
                  B站 登录状态
                </Text>
              </div>
              <div
                className="mt-2 flex flex-wrap items-center gap-2 rounded-[var(--md-sys-shape-corner)] p-1 transition-colors hover:cursor-pointer hover:bg-[var(--md-sys-color-surface-container-highest)]"
                role="button"
                tabIndex={0}
                onClick={() => {
                  if (bilibiliLoggedIn && bilibiliUser) {
                    setBangumiOpen(true)
                  } else {
                    handleOpenQrModal()
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault()
                    if (bilibiliLoggedIn && bilibiliUser) {
                      setBangumiOpen(true)
                    } else {
                      handleOpenQrModal()
                    }
                  }
                }}
              >
                {bilibiliLoggedIn && bilibiliUser ? (
                  <>
                    {avatarError || !bilibiliUser.avatar ? (
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-full"
                        style={{
                          backgroundColor: 'var(--glass-bg)',
                          border: '1px solid var(--md-sys-color-outline-variant)',
                        }}
                      >
                        <User className="h-3.5 w-3.5" />
                      </div>
                    ) : (
                      <img
                        src={buildBilibiliImageProxyUrl(bilibiliUser.avatar)}
                        alt={bilibiliUser.name}
                        className="h-6 w-6 rounded-full object-cover"
                        onError={() => setAvatarError(true)}
                      />
                    )}
                    <Text className="text-xs">{bilibiliUser.name}</Text>
                    {bilibiliUser.vipStatus === 1 ? (
                      <Tag color="warning" className="shrink-0 px-1.5 py-0 text-[10px]">
                        <Crown className="mr-0.5 h-3 w-3" />
                        大会员
                      </Tag>
                    ) : (
                      <Tag color="default" className="shrink-0 px-1.5 py-0 text-[10px]">
                        普通账号
                      </Tag>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      icon={<LogOut className="h-3 w-3" />}
                      onClick={(e) => {
                        e.stopPropagation()
                        handleLogoutBilibili()
                      }}
                    >
                      退出
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="secondary"
                    size="sm"
                    className="h-6 px-2 text-xs"
                    icon={<QrCode className="h-3 w-3" />}
                    onClick={(e) => {
                      e.stopPropagation()
                      handleOpenQrModal()
                    }}
                  >
                    扫码登录 B站
                  </Button>
                )}
              </div>
              <Paragraph type="secondary" className="m-0 mt-1.5 text-[11px]">
                {bilibiliLoggedIn
                  ? bilibiliUser?.vipStatus === 1
                    ? '大会员账号，可解析 4K / 1080P 高码率等专属画质'
                    : '已登录，可解析高画质视频'
                  : '未登录时只能解析低画质或试看片段'}
              </Paragraph>
              <BilibiliParseSettings />
            </div>
          )}
        </div>
      </div>

      {sourceType === 'bilibili' && (
        <BilibiliBangumiSelector
          open={bangumiOpen}
          onOpenChange={setBangumiOpen}
          onSelectEpisode={handleSelectBangumiEpisode}
          disabled={!isHost}
        />
      )}

      {sourceType === 'anime' && (
        <AniSubsSelector
          open={animeOpen}
          onOpenChange={setAnimeOpen}
          onSelectEpisode={handleSelectAnimeEpisode}
          disabled={!isHost}
        />
      )}

      {sourceType === 'kazumi' && (
        <KazumiSelector
          open={kazumiOpen}
          onOpenChange={setKazumiOpen}
          onSelectEpisode={handleSelectKazumiEpisode}
          disabled={!isHost}
        />
      )}

      <Modal
        open={qrModalOpen}
        onClose={handleCloseQrModal}
        title="扫码登录哔哩哔哩"
        footer={
          <Button variant="secondary" size="sm" onClick={handleCloseQrModal}>
            关闭
          </Button>
        }
      >
        <div className="flex flex-col items-center gap-4">
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt="哔哩哔哩登录二维码"
              className="rounded-lg border"
              style={{
                width: 200,
                height: 200,
                borderColor: 'var(--md-sys-color-outline-variant)',
              }}
            />
          ) : (
            <div
              className="glass flex items-center justify-center rounded-lg"
              style={{
                width: 200,
                height: 200,
              }}
            >
              <Text>正在生成二维码…</Text>
            </div>
          )}
          <Paragraph
            type={
              qrStatus === 2
                ? 'success'
                : qrStatus === 3
                  ? 'danger'
                  : 'secondary'
            }
            className="m-0 text-sm"
          >
            {qrMessage}
          </Paragraph>
          {qrStatus === 3 && (
            <Button variant="primary" size="sm" onClick={handleOpenQrModal}>
              重新获取二维码
            </Button>
          )}
        </div>
      </Modal>

      {browsingMount?.type === 'webdav' ? (
        <WebDAVBrowser
          mountId={browsingMount.id}
          open={!!browsingMount}
          onClose={() => setBrowsingMount(null)}
          onSelectFiles={handleSelectFilesFromMount}
          selectable
        />
      ) : browsingMount?.type === 'openlist' ? (
        <OpenListBrowser
          mountId={browsingMount.id}
          open={!!browsingMount}
          onClose={() => setBrowsingMount(null)}
          onSelectFiles={handleSelectFilesFromMount}
          selectable
        />
      ) : (
        <MountBrowser
          mount={browsingMount}
          open={!!browsingMount}
          onClose={() => setBrowsingMount(null)}
          onSelectFiles={handleSelectFilesFromMount}
          selectable
        />
      )}

      <ServerFilesBrowser
        open={serverFilesBrowserOpen}
        onClose={() => setServerFilesBrowserOpen(false)}
        onSelectFile={(path) => setServerFilePath(path)}
        selectable
      />
    </>
  )
}
