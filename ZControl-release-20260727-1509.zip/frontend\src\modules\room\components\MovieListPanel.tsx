import { useState, useMemo, useEffect } from 'react'
import {
  Play,
  Trash2,
  Film,
  Monitor,
  ListVideo,
  Maximize,
} from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Text, Paragraph } from '@/components/ui/Typography'
import { Tag } from '@/components/ui/Tag'
import { Select } from '@/components/ui/Select'
import { Modal } from '@/components/ui/Modal'
import { message } from '@/components/ui/message'
import { useSocket } from '@/hooks/useSocket'
import { useRoomStore, type Movie } from '@/store/roomStore'
import {
  resolveBilibiliWithOptions,
  filterQualitiesByVip,
  getBilibiliUserInfo,
} from '@/modules/bilibili/bilibiliApi'
import { useBilibiliParsePreferences } from '@/modules/bilibili/parseOptions'
import { cn } from '@/lib/utils'

interface MovieListPanelProps {
  isHost: boolean
}

const SOURCE_LABELS: Record<string, string> = {
  bilibili: '哔哩哔哩',
  mp4: 'MP4',
  webdav: 'WebDAV',
  ftp: 'FTP',
  openlist: 'OpenList',
  smb: 'SMB',
}

export function MovieListPanel({ isHost }: MovieListPanelProps) {
  const { socket } = useSocket()
  const movies = useRoomStore((state) => state.movies)
  const currentMovieId = useRoomStore((state) => state.currentMovieId)
  const setCurrentMovieId = useRoomStore((state) => state.setCurrentMovieId)
  const roomId = useRoomStore((state) => state.roomId)
  const removeMovie = useRoomStore((state) => state.removeMovie)
  const updateMovie = useRoomStore((state) => state.updateMovie)
  const setPendingQualityChange = useRoomStore(
    (state) => state.setPendingQualityChange
  )
  const mode = useRoomStore((state) => state.mode)
  const [search, setSearch] = useState('')
  const [removingId, setRemovingId] = useState<number | null>(null)
  const [qualityLoadingId, setQualityLoadingId] = useState<number | null>(null)
  const [pageLoadingId, setPageLoadingId] = useState<number | null>(null)
  const [bilibiliVip, setBilibiliVip] = useState(false)
  // 播放模式偏好通过 hook 跨组件同步：BilibiliParseSettings 已移至 MoviePushPanel，
  // 此处仅读取 preferMp4 用于禁用影片列表的分辨率 Select
  // （B站 MP4 直链通常仅支持 480P/720P，DASH 才支持 1080P/4K，无需也不能切换）
  const { preferMp4 } = useBilibiliParsePreferences()
  const isScreenShare = mode === 'screen-share'

  // 弹窗显示完整影片列表
  const [showListModal, setShowListModal] = useState(false)

  // 获取当前 B站 会员状态，用于过滤清晰度列表
  const hasBilibiliMovie = movies.some((m) => m.sourceType === 'bilibili')
  useEffect(() => {
    if (!hasBilibiliMovie) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- 无 B站影片时重置会员状态
      setBilibiliVip(false)
      return
    }
    let cancelled = false
    getBilibiliUserInfo().then((info) => {
      if (!cancelled) setBilibiliVip(info?.vipStatus === 1)
    })
    return () => {
      cancelled = true
    }
  }, [hasBilibiliMovie])

  const filteredMovies = useMemo(() => {
    if (!search.trim()) return movies
    const keyword = search.trim().toLowerCase()
    return movies.filter((m) => m.title.toLowerCase().includes(keyword))
  }, [movies, search])

  const handlePlay = (movieId: number) => {
    if (!isHost) {
      message.info('只有房主可以切换影片')
      return
    }
    if (!socket) {
      message.error('未连接房间')
      return
    }
    socket.emit('play-movie', { roomId, movieId })
    setCurrentMovieId(movieId)
  }

  const handleRemove = async (movieId: number) => {
    if (!isHost) {
      message.info('只有房主可以删除影片')
      return
    }
    if (!roomId) {
      message.error('未连接房间')
      return
    }
    setRemovingId(movieId)
    try {
      await removeMovie(roomId, movieId)
      message.success('影片已删除')
    } catch (err) {
      console.error('[MovieListPanel] remove movie error:', err)
      message.error(err instanceof Error ? err.message : '删除影片失败')
    } finally {
      setRemovingId(null)
    }
  }

  const handleQualityChange = async (movie: Movie, value: string) => {
    if (!isHost || isScreenShare || !roomId) return
    const qn = Number(value)
    if (!Number.isFinite(qn) || qn === movie.currentQn) return

    setQualityLoadingId(movie.id)
    try {
      // 透传当前播放模式偏好，避免 MP4 模式下切换清晰度时被改回 DASH
      const resolved = await resolveBilibiliWithOptions(movie.url, qn, undefined, {
        preferMp4,
      })
      await updateMovie(roomId, movie.id, {
        audioUrl: resolved.audioUrl,
        format: resolved.format,
        videoCodec: resolved.videoCodec,
        audioCodec: resolved.audioCodec,
        duration: resolved.duration,
        cid: resolved.cid,
        currentQn: resolved.currentQn,
        acceptQuality: resolved.acceptQuality,
      })
      if (movie.id === currentMovieId) {
        setPendingQualityChange({ movieId: movie.id, resolved })
      }
    } catch (err) {
      console.error('[MovieListPanel] change quality error:', err)
      message.error(err instanceof Error ? err.message : '切换清晰度失败')
    } finally {
      setQualityLoadingId(null)
    }
  }

  /**
   * 切换分P（分集）。
   *
   * 多 P 视频每个分集有独立的 cid 和 m4s 文件，必须用对应 cid 重新请求 playurl。
   * 切换后更新 movie 的 cid/duration/videoUrl/audioUrl 等字段，并触发当前播放影片的重新 attach。
   */
  const handlePageChange = async (movie: Movie, value: string) => {
    if (!isHost || isScreenShare || !roomId) return
    const page = Number(value)
    if (!Number.isFinite(page) || page === movie.currentPage) return

    setPageLoadingId(movie.id)
    try {
      // 透传当前播放模式偏好和清晰度，保持切换分P 后清晰度一致
      const resolved = await resolveBilibiliWithOptions(
        movie.url,
        movie.currentQn,
        undefined,
        {
          preferMp4,
          page,
        }
      )
      await updateMovie(roomId, movie.id, {
        audioUrl: resolved.audioUrl,
        format: resolved.format,
        videoCodec: resolved.videoCodec,
        audioCodec: resolved.audioCodec,
        duration: resolved.duration,
        cid: resolved.cid,
        currentQn: resolved.currentQn,
        acceptQuality: resolved.acceptQuality,
        currentPage: resolved.currentPage ?? page,
      })
      if (movie.id === currentMovieId) {
        setPendingQualityChange({ movieId: movie.id, resolved })
      }
    } catch (err) {
      console.error('[MovieListPanel] change page error:', err)
      message.error(err instanceof Error ? err.message : '切换分P失败')
    } finally {
      setPageLoadingId(null)
    }
  }

  // 影片列表内容（卡片和弹窗共用）
  const movieListContent = (
    <>
      {isScreenShare && (
        <div
          className="flex items-center gap-2 rounded-[var(--md-sys-shape-corner)] p-2"
          style={{
            backgroundColor:
              'color-mix(in srgb, var(--md-sys-color-secondary-container) calc(var(--glass-strength) * 100%), transparent)',
          }}
        >
          <Monitor
            className="h-4 w-4 flex-shrink-0"
            style={{ color: 'var(--md-sys-color-secondary)' }}
          />
          <Paragraph type="secondary" className="m-0 text-xs">
            当前为远程共享模式，影片播放已暂停
          </Paragraph>
        </div>
      )}

      <Input
        size="sm"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="搜索影片…"
      />

      {/* 影片列表滚动区域 */}
      <div className="min-h-[120px] min-w-0 flex-1 overflow-y-auto rounded-[var(--md-sys-shape-corner)]">
        {filteredMovies.length === 0 && (
          <div className="flex flex-col items-center justify-center gap-2 py-8 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full"
              style={{
                backgroundColor: 'var(--glass-bg)',
              }}
            >
              <Film
                className="h-5 w-5 opacity-40"
                style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
              />
            </div>
            <Paragraph type="secondary" className="m-0 text-xs">
              {search ? '未找到匹配的影片' : '暂无影片，请在右侧添加'}
            </Paragraph>
          </div>
        )}
        <div className="flex flex-col gap-1.5">
          {filteredMovies.map((movie, idx) => {
            const isActive = movie.id === currentMovieId
            return (
              <div
                key={movie.id}
                className={cn(
                  'zen-item-enter rounded-[var(--md-sys-shape-corner)] border p-2.5 transition-all',
                  isActive
                    ? 'border-[var(--md-sys-color-primary)] bg-[var(--md-sys-color-primary-container)] shadow-md'
                    : 'glass border-transparent hover:-translate-y-0.5 hover:border-[var(--md-sys-color-outline-variant)] hover:shadow-md'
                )}
                style={
                  {
                    '--item-delay': `${idx * 50}ms`,
                  } as React.CSSProperties
                }
              >
                <div
                  draggable={false}
                  className={cn(
                    'grid items-center gap-2',
                    isHost
                      ? 'grid-cols-[auto_1fr_auto_auto]'
                      : 'grid-cols-[auto_1fr]'
                  )}
                >
                  <div
                    className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[var(--md-sys-shape-corner)]"
                    style={{
                      background: isActive
                        ? 'var(--md-sys-color-primary)'
                        : 'color-mix(in srgb, var(--md-sys-color-primary) 12%, transparent)',
                    }}
                  >
                    <Film
                      className="h-3 w-3"
                      style={{
                        color: isActive
                          ? 'var(--md-sys-color-on-primary)'
                          : 'var(--md-sys-color-primary)',
                      }}
                    />
                  </div>
                  <div className="min-w-0 overflow-hidden">
                    <Paragraph
                      className="m-0 truncate text-xs font-medium"
                      title={movie.title}
                    >
                      {movie.title}
                    </Paragraph>
                    <div className="mt-1 flex items-center gap-1.5">
                      <Tag
                        color="primary"
                        className="inline-flex min-w-0 max-w-full truncate"
                      >
                        {SOURCE_LABELS[movie.sourceType] || movie.sourceType}
                      </Tag>
                      {movie.pages && movie.pages.length > 1 && (
                        <Tag
                          className="inline-flex items-center gap-1"
                          style={{
                            backgroundColor:
                              'color-mix(in srgb, var(--md-sys-color-tertiary-container) calc(var(--glass-strength) * 100%), transparent)',
                            color:
                              'var(--md-sys-color-on-tertiary-container)',
                          }}
                        >
                          <ListVideo className="h-2.5 w-2.5" />
                          P{movie.currentPage ?? 1}/{movie.pages.length}
                        </Tag>
                      )}
                    </div>
                    {isHost &&
                      movie.sourceType === 'bilibili' &&
                      movie.acceptQuality &&
                      movie.acceptQuality.length > 0 && (
                        <Select
                          className="mt-1.5"
                          size="sm"
                          value={String(
                            movie.currentQn ?? movie.acceptQuality[0]?.id
                          )}
                          options={filterQualitiesByVip(
                            movie.acceptQuality,
                            bilibiliVip
                          ).map((q) => ({
                            label: q.resolution
                              ? `${q.label} · ${q.resolution}`
                              : q.label,
                            value: String(q.id),
                          }))}
                          disabled={
                            !isHost ||
                            isScreenShare ||
                            qualityLoadingId === movie.id ||
                            preferMp4
                          }
                          onChange={(value) =>
                            handleQualityChange(movie, value)
                          }
                        />
                      )}
                    {isHost &&
                      movie.sourceType === 'bilibili' &&
                      movie.pages &&
                      movie.pages.length > 1 && (
                        <Select
                          className="mt-1.5"
                          size="sm"
                          value={String(movie.currentPage ?? 1)}
                          options={movie.pages.map((p) => ({
                            label: `P${p.page} ${p.part}`,
                            value: String(p.page),
                          }))}
                          disabled={
                            !isHost ||
                            isScreenShare ||
                            pageLoadingId === movie.id
                          }
                          onChange={(value) =>
                            handlePageChange(movie, value)
                          }
                        />
                      )}
                  </div>
                  {isHost && (
                    <Button
                      variant={isActive ? 'primary' : 'secondary'}
                      size="sm"
                      className="h-7 flex-shrink-0 px-2"
                      icon={<Play className="h-3.5 w-3.5" />}
                      onClick={() => handlePlay(movie.id)}
                      disabled={!isHost || isScreenShare}
                      title={
                        isScreenShare
                          ? '远程共享模式下不可播放'
                          : isHost
                            ? '播放'
                            : '仅房主可播放'
                      }
                    />
                  )}
                  {isHost && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 flex-shrink-0 px-2"
                      icon={<Trash2 className="h-3.5 w-3.5" />}
                      onClick={() => handleRemove(movie.id)}
                      loading={removingId === movie.id}
                      disabled={!isHost || isScreenShare}
                      title={
                        isScreenShare
                          ? '远程共享模式下不可删除'
                          : isHost
                            ? '删除'
                            : '仅房主可删除'
                      }
                    />
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </>
  )

  return (
    <div className="glass-card zen-card flex h-full min-w-0 flex-col overflow-hidden rounded-[var(--md-sys-shape-corner)]">
      {/* 卡片头部：图标 + 标题 + 影片数量 + 全屏按钮 */}
      <div className="flex items-center gap-2.5 border-b border-[var(--glass-border)] px-4 py-3">
        <div
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--md-sys-shape-corner)]"
          style={{
            backgroundColor: 'var(--md-sys-color-primary-container)',
          }}
        >
          <Film
            className="h-4 w-4"
            style={{ color: 'var(--md-sys-color-on-primary-container)' }}
          />
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <Text className="text-sm font-semibold leading-tight">影片列表</Text>
          <Text
            type="secondary"
            className="text-[10px] uppercase tracking-wide"
          >
            {filteredMovies.length} 部影片
          </Text>
        </div>
        <button
          type="button"
          onClick={() => setShowListModal(true)}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[var(--md-sys-shape-corner)] transition-colors hover:bg-[var(--md-sys-color-surface-container-highest)]"
          style={{ color: 'var(--md-sys-color-on-surface-variant)' }}
          title="展开查看完整影片列表"
          aria-label="展开查看完整影片列表"
        >
          <Maximize className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* 卡片内容 */}
      <div className="zen-scroll flex min-h-0 flex-1 flex-col gap-2.5 overflow-y-auto px-4 py-3">
        {movieListContent}
      </div>

      {/* 完整影片列表弹窗 */}
      <Modal
        open={showListModal}
        onClose={() => setShowListModal(false)}
        title={`影片列表 (${movies.length} 部)`}
        className="max-w-2xl"
      >
        <div className="flex max-h-[70vh] flex-col gap-2.5 overflow-hidden">
          {movieListContent}
        </div>
      </Modal>
    </div>
  )
}
