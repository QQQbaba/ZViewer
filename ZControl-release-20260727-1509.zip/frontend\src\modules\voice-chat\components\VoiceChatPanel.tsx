import { useState } from 'react'
import { createPortal } from 'react-dom'
import {
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  Users,
  Headphones,
  ChevronDown,
  Volume2,
} from 'lucide-react'
import type { Socket } from 'socket.io-client'
import { useVoiceChat } from '../hooks/useVoiceChat'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/Button'
import { Slider } from '@/components/ui/Slider'

interface VoiceChatPanelProps {
  socket: Socket | null
  roomId: string | undefined
  username?: string
}

export function VoiceChatPanel({
  socket,
  roomId,
  username,
}: VoiceChatPanelProps) {
  const [expanded, setExpanded] = useState(false)
  const [editingPeer, setEditingPeer] = useState<string | null>(null)
  const {
    joined,
    joining,
    micEnabled,
    members,
    globalVolume,
    peerVolumes,
    peerLatencies,
    micVolume,
    monitorEnabled,
    join,
    leave,
    toggleMic,
    toggleMonitor,
    setGlobalVolume,
    setPeerVolume,
    setMicVolume,
  } = useVoiceChat({ socket, roomId, username })

  if (!roomId) return null

  const memberCount = members.length
  const isMe = (socketId: string) => socketId === socket?.id

  return createPortal(
    <div
      className={cn(
        'fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3',
        'transition-all duration-300'
      )}
    >
      {/* 展开的语音面板 */}
      {expanded && (
        <div
          className={cn(
            'glass-card flex w-64 flex-col overflow-hidden p-3',
            'zen-modal-content-enter'
          )}
          style={{ maxHeight: 'min(420px, calc(100vh - 160px))' }}
        >
          {/* 标题栏 */}
          <div className="mb-2 flex items-center gap-2">
            <div
              className="flex h-8 w-8 items-center justify-center rounded-[var(--md-sys-shape-corner)]"
              style={{
                backgroundColor: 'var(--md-sys-color-primary-container)',
                color: 'var(--md-sys-color-on-primary-container)',
              }}
            >
              <Headphones className="h-4 w-4" />
            </div>
            <div className="flex flex-1 flex-col">
              <span className="text-sm font-medium text-[var(--md-sys-color-on-surface)]">
                语音聊天
              </span>
              <span className="text-[10px] uppercase tracking-wide text-[var(--md-sys-color-on-surface-variant)]">
                {joined ? `${memberCount} 人在线` : '未连接'}
              </span>
            </div>
            <button
              onClick={() => setExpanded(false)}
              className="rounded-full p-1 text-[var(--md-sys-color-on-surface-variant)] transition-colors hover:bg-[var(--md-sys-color-surface-container-highest)]"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>

          {/* 全局音量 */}
          {joined && (
            <div className="mb-1.5 rounded-[var(--md-sys-radius-small)] bg-[var(--glass-bg)] px-2 py-1.5">
              <div className="mb-0.5 text-xs font-medium text-[var(--md-sys-color-on-surface)]">
                全局音量
              </div>
              <div className="flex items-center gap-2">
                <Slider
                  size="sm"
                  showValue={false}
                  value={Math.round(globalVolume * 100)}
                  min={0}
                  max={100}
                  step={1}
                  onChange={(v) => setGlobalVolume(v / 100)}
                  className="flex-1"
                />
                <span className="w-9 text-right text-xs font-medium tabular-nums text-[var(--md-sys-color-on-surface-variant)]">
                  {Math.round(globalVolume * 100)}%
                </span>
              </div>
            </div>
          )}

          {/* 麦克风音量（对所有远端用户生效） */}
          {joined && (
            <div className="mb-1.5 rounded-[var(--md-sys-radius-small)] bg-[var(--glass-bg)] px-2 py-1.5">
              <div className="mb-0.5 text-xs font-medium text-[var(--md-sys-color-on-surface)]">
                麦克风音量
              </div>
              <div className="flex items-center gap-2">
                <Slider
                  size="sm"
                  showValue={false}
                  value={Math.round(micVolume * 100)}
                  min={0}
                  max={100}
                  step={1}
                  onChange={(v) => setMicVolume(v / 100)}
                  className="flex-1"
                />
                <span className="w-9 text-right text-xs font-medium tabular-nums text-[var(--md-sys-color-on-surface-variant)]">
                  {Math.round(micVolume * 100)}%
                </span>
              </div>
            </div>
          )}

          {/* 成员列表 */}
          {joined && memberCount > 0 && (
            <div className="mb-2 flex-1 space-y-1.5 overflow-y-auto pr-1">
              {members.map((member) => {
                const me = isMe(member.socketId)
                const peerVolume = peerVolumes.get(member.socketId) ?? 1
                return (
                  <div
                    key={member.socketId}
                    className="rounded-[var(--md-sys-radius-small)] bg-[var(--glass-bg)] px-2 py-1.5"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-full"
                        style={{
                          backgroundColor: me
                            ? 'var(--md-sys-color-primary-container)'
                            : 'var(--md-sys-color-surface-container-high)',
                          color: me
                            ? 'var(--md-sys-color-on-primary-container)'
                            : 'var(--md-sys-color-on-surface-variant)',
                        }}
                      >
                        {me ? (
                          micEnabled ? (
                            <Mic className="h-3 w-3" />
                          ) : (
                            <MicOff className="h-3 w-3" />
                          )
                        ) : (
                          <Users className="h-3 w-3" />
                        )}
                      </div>
                      <span className="flex-1 truncate text-xs font-medium text-[var(--md-sys-color-on-surface)]">
                        {me ? '我' : member.username || '观众'}
                      </span>
                      {!me && (
                        <span className="text-[10px] tabular-nums text-[var(--md-sys-color-on-surface-variant)]">
                          {peerLatencies.has(member.socketId)
                            ? `${peerLatencies.get(member.socketId)}ms`
                            : '-'}
                        </span>
                      )}
                      {me && !micEnabled && (
                        <MicOff className="h-3 w-3 text-[var(--md-sys-color-error)]" />
                      )}
                      {!me && (
                        <button
                          onClick={() =>
                            setEditingPeer((prev) =>
                              prev === member.socketId ? null : member.socketId
                            )
                          }
                          className={cn(
                            'rounded-full p-1 transition-colors',
                            editingPeer === member.socketId
                              ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)]'
                              : 'text-[var(--md-sys-color-on-surface-variant)] hover:bg-[var(--md-sys-color-surface-container-highest)]'
                          )}
                        >
                          <Volume2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                    {!me && editingPeer === member.socketId && (
                      <div className="mt-2">
                        <Slider
                          size="sm"
                          label="单独音量"
                          value={Math.round(peerVolume * 100)}
                          min={0}
                          max={100}
                          step={1}
                          valueFormatter={(v) => `${v}%`}
                          onChange={(v) =>
                            setPeerVolume(member.socketId, v / 100)
                          }
                        />
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}

          {/* 未加入提示 */}
          {!joined && !joining && (
            <div className="mb-3 text-center text-xs text-[var(--md-sys-color-on-surface-variant)]">
              点击加入即可与房间内其他观众语音交流
            </div>
          )}

          {/* 操作按钮 */}
          <div className="flex gap-2">
            {joined ? (
              <>
                <Button
                  variant="secondary"
                  size="sm"
                  className="flex-1 whitespace-nowrap"
                  icon={
                    micEnabled ? (
                      <Mic className="h-3.5 w-3.5" />
                    ) : (
                      <MicOff className="h-3.5 w-3.5" />
                    )
                  }
                  onClick={toggleMic}
                >
                  {micEnabled ? '静音' : '取消静音'}
                </Button>
                <Button
                  variant={monitorEnabled ? 'primary' : 'secondary'}
                  size="sm"
                  icon={<Headphones className="h-3.5 w-3.5" />}
                  onClick={toggleMonitor}
                  title={monitorEnabled ? '关闭反送' : '开启反送'}
                />
                <Button
                  variant="danger"
                  size="sm"
                  className="flex-1"
                  icon={<PhoneOff className="h-3.5 w-3.5" />}
                  onClick={leave}
                >
                  断开
                </Button>
              </>
            ) : (
              <Button
                variant="primary"
                size="sm"
                block
                loading={joining}
                icon={<Phone className="h-3.5 w-3.5" />}
                onClick={join}
              >
                加入语音
              </Button>
            )}
          </div>
        </div>
      )}

      {/* 悬浮触发按钮 */}
      {!expanded && (
        <button
          onClick={() => setExpanded(true)}
          className={cn(
            'glass-card flex h-12 w-12 items-center justify-center rounded-full shadow-lg transition-all duration-200',
            'hover:scale-105 hover:shadow-xl active:scale-95',
            joined && 'ring-2 ring-[var(--md-sys-color-primary)]'
          )}
          style={{
            backgroundColor: joined
              ? 'var(--md-sys-color-primary-container)'
              : 'var(--glass-bg)',
            color: joined
              ? 'var(--md-sys-color-on-primary-container)'
              : 'var(--md-sys-color-on-surface)',
          }}
          title="语音聊天"
        >
          {joined ? (
            micEnabled ? (
              <Mic className="h-5 w-5" />
            ) : (
              <MicOff className="h-5 w-5" />
            )
          ) : (
            <Headphones className="h-5 w-5" />
          )}
          {joined && memberCount > 1 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--md-sys-color-primary)] px-1 text-[10px] font-medium text-[var(--md-sys-color-on-primary)]">
              {memberCount}
            </span>
          )}
        </button>
      )}
    </div>,
    document.body
  )
}
